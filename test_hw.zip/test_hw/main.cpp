#include <iostream>
#include "vector.hpp"

using namespace std;

int main() {
    rm::Vector v1 = {3.0, 4.0};
    rm::Vector v2 = {1.0, 2.0};

    cout << "=== 测试开始 ===" << endl;
    cout << "v1 的模长: " << rm::length(v1) << endl; 
    cout << "v1 和 v2 的距离: " << rm::distance(v1, v2) << endl;
    cout << "v1 和 v2 的点乘: " << rm::dot(v1, v2) << endl;
    
    rm::Vector v3 = rm::scale(v1, 2.0);
    cout << "v1 缩放 2 倍后的第一个元素: " << v3[0] << endl;

    rm::Vector v4 = rm::normalize(v1);
    cout << "v1 单位化后的第一个元素: " << v4[0] << endl;

    cout << "v1 和 v2 的夹角(弧度): " << rm::angleBetween(v1, v2) << endl;
    cout << "=== 测试结束 ===" << endl;

    return 0;
}