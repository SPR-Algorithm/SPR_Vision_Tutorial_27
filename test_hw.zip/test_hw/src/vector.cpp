#include "vector.hpp"
#include <stdexcept>

namespace rm {

double length(const Vector& v) {
    double sum = 0.0;
    for (size_t i = 0; i < v.size(); ++i) sum += v[i] * v[i];
    return std::sqrt(sum);
}

double distance(const Vector& a, const Vector& b) {
    if (a.size() != b.size()) throw std::invalid_argument("维度不一致");
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i) {
        double diff = a[i] - b[i];
        sum += diff * diff;
    }
    return std::sqrt(sum);
}

double dot(const Vector& a, const Vector& b) {
    if (a.size() != b.size()) throw std::invalid_argument("维度不一致");
    double sum = 0.0;
    for (size_t i = 0; i < a.size(); ++i) sum += a[i] * b[i];
    return sum;
}

Vector scale(const Vector& v, double k) {
    Vector res;
    for (size_t i = 0; i < v.size(); ++i) res.push_back(v[i] * k);
    return res;
}

Vector normalize(const Vector& v) {
    double len = length(v);
    if (len == 0) throw std::domain_error("零向量不能单位化");
    Vector res;
    for (size_t i = 0; i < v.size(); ++i) res.push_back(v[i] / len);
    return res;
}

double angleBetween(const Vector& a, const Vector& b) {
    double len_a = length(a);
    double len_b = length(b);
    if (len_a == 0 || len_b == 0) throw std::domain_error("零向量没有夹角");
    double cos_val = dot(a, b) / (len_a * len_b);
    if (cos_val > 1.0) cos_val = 1.0;
    if (cos_val < -1.0) cos_val = -1.0;
    return std::acos(cos_val);
}

} // namespace rm
