cmake_minimum_required(VERSION 3.10)
project(VectorLib)

set(CMAKE_CXX_STANDARD 17)

# 把 src 里的实现编译成静态库
add_library(rm_vector STATIC src/vector.cpp)

# 把 include 目录暴露出去
target_include_directories(rm_vector PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)