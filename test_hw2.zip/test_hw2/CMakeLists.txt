cmake_minimum_required(VERSION 3.10)
project(SprVisionHW2)

set(CMAKE_CXX_STANDARD 17)

# 寻找 OpenCV 库 
find_package(OpenCV REQUIRED)

# 把 camera.cpp 编译成静态库
add_library(camera_lib STATIC src/camera.cpp)
# 让 camera_lib 能找到 include 里的头文件
target_include_directories(camera_lib PUBLIC ${CMAKE_CURRENT_SOURCE_DIR}/include)
# 链接 OpenCV
target_link_libraries(camera_lib PUBLIC ${OpenCV_LIBS})

# 编译 main.cpp
add_executable(main src/main.cpp)
# 把刚才的静态库和 main 链接起来
target_link_libraries(main PRIVATE camera_lib)