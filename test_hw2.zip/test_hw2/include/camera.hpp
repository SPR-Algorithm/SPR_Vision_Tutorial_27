#pragma once
#include <opencv2/opencv.hpp>

namespace io {
    // 1. 纯虚基类（接口）
    class CameraBase {
    public:
        virtual ~CameraBase() = default;
        virtual bool read(cv::Mat& img) = 0; 
    };

    // 2. 具体实现类（告诉 main.cpp 它的存在）
    class DummyCamera : public CameraBase {
    public:
        bool read(cv::Mat& img) override; 
    };
}
// 加一个 USB 相机派生类
class UsbCamera : public CameraBase {
public:
    bool read(cv::Mat& img) override;
};
