#include "../include/camera.hpp"

namespace io {
    // 这里只写具体的实现逻辑，不再写 class DummyCamera { ... } 的整体定义了
    bool DummyCamera::read(cv::Mat& img) {
        // 造一张640x480的黑图返回，防止程序空指针崩溃
        img = cv::Mat(480, 640, CV_8UC3, cv::Scalar(0, 0, 0));
        return true;
    }
}
bool UsbCamera::read(cv::Mat& img) {
    // 假装用 OpenCV 读 USB 相机，这里随便造个红图
    img = cv::Mat(480, 640, CV_8UC3, cv::Scalar(0, 0, 255));
    return true;
}