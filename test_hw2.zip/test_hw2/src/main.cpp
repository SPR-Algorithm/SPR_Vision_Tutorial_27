#include "../include/camera.hpp"
#include <iostream>

int main() {
    std::cout << "SPR 视觉流水线启动..." << std::endl;
    
    io::CameraBase* cam = new io::DummyCamera();
    cv::Mat frame;

    // 模拟死循环
    for (int i = 0; i < 5; ++i) {
        if (cam->read(frame)) {
            std::cout << "成功读取一帧图像, 尺寸: " << frame.cols << "x" << frame.rows << std::endl;
        }
    }
    
    delete cam;
    std::cout << "测试结束。" << std::endl;
    return 0;
}
